1. INSTALACAO
   Leia https://raw.github.com/drupalista-br/Boleto/master/readme.txt

2. ARGUMENTOS
 'carteira'     ->  06 ou 03 (Verifique com o gerente)
 'nosso_numero' ->  Max 11 characters

