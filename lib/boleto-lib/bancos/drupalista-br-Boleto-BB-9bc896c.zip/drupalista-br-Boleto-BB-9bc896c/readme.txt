1. INSTALACAO
   Leia https://raw.github.com/drupalista-br/Boleto/master/readme.txt


2. ARGUMENTOS - CARTEIRA 18

   - Carteira 18 com Convenio de 8 digitos
     Nosso número: pode ser até 9 dígitos

   - Carteira 18 com Convenio de 7 digitos
     Nosso número: pode ser até 10 dígitos

   - Carteira 18 com Convenio de 6 digitos
     Nosso número:
     de 1 a 99999 para opção de até 5 dígitos
     de 1 a 99999999999999999 para opção de até 17 dígitos

     'carteira' => 18, ambos os formatos XX ou XX-XXX sao aceitos
 
     'carteira_nosso_numero - Formato: aaaaaa-bbbbbb-cc, Por Exemplo: '222222-333333-21'
		                       Sendo que:
                                       aaaaaa - Especifique o numero do convenio o qual pode conter 6, 7 ou 8 digitos.
                                       bbbbbb - Especifique o numero do contrato.
                                       cc     - (opcional) Quando especificado este tem que ser 21. 
                                                           So sera considerado quando o convenio for de 6 digitos
     'conta'       - Conta é sempre 8 digitos
     'agencia_dv'  - E' automaticamente calculado quando argumento nao estiver presente.


/** No momento somente a carteira 18 esta implementada  **/

Por favor ajude doando o seu tempo para implementar mais carteiras
Documentacao em www.bb.com.br/docs/pub/emp/empl/dwn/Doc5175Bloqueto.pdf

Carteiras que ainda precisam ser implementadas Banco do Brasil:
- Carteira 11.
- Carteira 16, convênio 4 dígitos.
- Carteira 16, convênio 6 dígitos.
- Carteira 16, convênio 6 dígitos, nosso número com 17 dígitos.
- Carteira 16, sem convênio.
- Carteira 17, convênio 4 dígitos.
- Carteira 17, convênio 6 dígitos.
- Carteira 17, convênio 7 dígitos, nosso número com 17 dígitos.
- Carteira 18, convênio 4 dígitos.
- Carteira 18, convênio 6 dígitos.
- Carteira 18, convênio 6 dígitos, nosso número com 17 dígitos.
- Carteira 18, convênio 7 dígitos, nosso número com 17 dígitos.
- Carteira 18, sem convênio.
- Carteira 18-011, convênio 4 dígitos.
- Carteira 18-011, convênio 6 dígitos.
- Carteira 18-011, convênio 6 dígitos, nosso número com 17 dígitos.
- Carteira 18-011, convênio 7 dígitos, nosso número com 17 dígitos.
- Carteira 18-011, sem convênio.
- Carteira 18-019, convênio 4 dígitos.
- Carteira 18-019, convênio 6 dígitos.
- Carteira 18-019, convênio 6 dígitos, nosso número com 17 dígitos.
- Carteira 18-019, convênio 7 dígitos, nosso número com 17 dígitos.
- Carteira 18-019, sem convênio.
- Carteira 18-027, convênio 7 dígitos, nosso número com 17 dígitos.
- Carteira 51.
